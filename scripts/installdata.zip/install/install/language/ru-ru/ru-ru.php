<?php
// Button
$_['button_continue'] = 'Продолжить';
$_['button_back']     = 'Назад';

// Error
$_['error_exception'] = 'Ошибка (%s): %s в %s строка %s';