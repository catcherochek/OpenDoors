<?php
$_['text_project']       = 'Русское сообщество OpenCart';
$_['text_documentation'] = 'Документация';
$_['text_support']       = 'Форум поддержки';
$_['text_footer']        = 'Copyright © 2016 Opencart Россия - Все права защищены';