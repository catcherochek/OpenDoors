<?php
// URL Params delimeters
$_['ocfilter_part_separator'] = ';';
$_['ocfilter_option_separator'] = ':';
$_['ocfilter_option_value_separator'] = ',';

// URL GET index
$_['ocfilter_url_index'] = 'filter_ocfilter';